using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Microsoft.Maui.Controls;
using System.Text;
using System.Windows.Input;
using System.Linq;

namespace MauiProject_Candela
{
    public partial class ToDo : ContentPage
    {
        private readonly HttpClient _httpClient = new HttpClient();
        public ObservableCollection<ToDoItemViewModel> ToDoItems { get; set; } = new();

        public ToDo()
        {
            InitializeComponent();
            BindingContext = this;
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();

            var userId = Preferences.Get("UserId", 0);
            if (userId == 0)
            {
                await DisplayAlert("Error", "No user logged in.", "OK");
                return;
            }

            await LoadTasks("active");
        }

        private async Task LoadTasks(string status)
        {
            try
            {
                var userId = Preferences.Get("UserId", 0);
                string url = $"https://todo-list.dcism.org/getItems_action.php?status={status}&user_id={userId}";
                var response = await _httpClient.GetStringAsync(url);
                var apiResponse = JsonConvert.DeserializeObject<GetItemsResponse>(response);

                if (apiResponse.status == 200)
                {
                    var newList = new ObservableCollection<ToDoItemViewModel>();

                    foreach (var item in apiResponse.data.Values)
                    {
                        newList.Add(new ToDoItemViewModel
                        {
                            ItemId = item.item_id,
                            TaskName = item.item_name,
                            Description = item.item_description,
                            Status = item.status,
                            DeleteCommand = new Command(async () => await DeleteTask(item.item_id)),
                            CompleteCommand = new Command(async () => await CompleteTask(item.item_id))
                        });
                    }

                    await Device.InvokeOnMainThreadAsync(() =>
                    {
                        ToDoItems.Clear();
                        foreach (var item in newList)
                            ToDoItems.Add(item);
                    });
                }
                else
                {
                    await DisplayAlert("Error", "Failed to load tasks.", "OK");
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }
        private async void OnSelectionChanged(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem is ToDoItemViewModel selectedItem)
            {
                ((ListView)sender).SelectedItem = null; // Deselect ASAP to prevent retrigger

                // Defensive check to avoid multiple navigations if user taps fast
                if (Navigation.NavigationStack.LastOrDefault()?.GetType() != typeof(EditTask))
                {
                    await Navigation.PushAsync(new EditTask(selectedItem));
                }
            }
        }

        private async Task CompleteTask(int itemId)
        {
            try
            {
                var task = ToDoItems.FirstOrDefault(t => t.ItemId == itemId);
                if (task == null)
                {
                    await DisplayAlert("Error", "Task not found.", "OK");
                    return;
                }

                var updateUrl = "https://todo-list.dcism.org/statusItem_action.php";
                var updateData = new
                {
                    status = "inactive",
                    item_id = itemId
                };

                var jsonContent = JsonConvert.SerializeObject(updateData);
                var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.PutAsync(updateUrl, content);
                var responseString = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode && responseString.TrimStart().StartsWith("{"))
                {
                    var result = JsonConvert.DeserializeObject<UpdateTaskResponse>(responseString);
                    if (result.status == 200)
                    {
                        await Device.InvokeOnMainThreadAsync(() =>
                        {
                            ToDoItems.Remove(task);
                        });

                        await DisplayAlert("Success", "Task marked as complete.", "OK");
                    }
                    else
                    {
                        await DisplayAlert("Error", "Failed to update task.", "OK");
                    }
                }
                else
                {
                    await DisplayAlert("Error", $"Unexpected response: {responseString}", "OK");
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");
            }
        }

        private async Task DeleteTask(int itemId)
        {
            try
            {
                var deleteUrl = $"https://todo-list.dcism.org/deleteItem_action.php?item_id={itemId}";
                var response = await _httpClient.DeleteAsync(deleteUrl);
                var responseString = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode && responseString.StartsWith("{"))
                {
                    var result = JsonConvert.DeserializeObject<UpdateTaskResponse>(responseString);
                    if (result.status == 200)
                    {
                        var task = ToDoItems.FirstOrDefault(t => t.ItemId == itemId);
                        if (task != null)
                        {
                            ToDoItems.Remove(task);
                        }

                        await DisplayAlert("Deleted", "Task was successfully deleted.", "OK");
                    }
                    else
                    {
                        await DisplayAlert("Error", "Failed to delete task.", "OK");
                    }
                }
                else
                {
                    await DisplayAlert("Error", $"Unexpected response: {responseString}", "OK");
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");
            }
        }


        private async void AddButtonPressed(object sender, EventArgs e)
        {
            var userId = Preferences.Get("UserId", 0);
            if (userId != 0)
            {
                await Navigation.PushModalAsync(new AddTodoTask(userId));
            }
            else
            {
                await DisplayAlert("Error", "You must be signed in to add a task.", "OK");
            }
        }

        // Classes
        public class GetItemsResponse
        {
            public int status { get; set; }
            public Dictionary<string, AuthService.TaskData> data { get; set; }
            public string count { get; set; }
        }

        public class UpdateTaskResponse
        {
            public int status { get; set; }
            public string message { get; set; }
        }

        public class ToDoItemViewModel
        {
            public string TaskName { get; set; }
            public int ItemId { get; set; }
            public string Status { get; set; }
            public string Description { get; set; }
            public ICommand DeleteCommand { get; set; }
            public ICommand CompleteCommand { get; set; }
        }
    }
}
