using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace MauiProject_Candela;

public partial class SignIn : ContentPage
{
    public SignIn()
    {
        InitializeComponent();
    }
    private async void SignIn_Clicked(object sender, EventArgs e)
    {
        var email = EmailEntry.Text;
        var password = PasswordEntry.Text;

        if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
        {
            await DisplayAlert("Error", "Please enter both email and password.", "OK");
            return;
        }

        var signInUrl = $"https://todo-list.dcism.org/signin_action.php?email={Uri.EscapeDataString(email)}&password={Uri.EscapeDataString(password)}";

        try
        {
            var httpClient = new HttpClient();
            var response = await httpClient.GetStringAsync(signInUrl);

            var result = JsonConvert.DeserializeObject<AuthService.SignInResponse>(response);

            if (result.status == 200)
            {
                var userData = result.data;
                Preferences.Set("UserId", userData.id);
                // ✅ Save user info if "Keep me signed in" is checked
                if (KeepSignedInCheckBox.IsChecked)
                {
                    Preferences.Set("IsSignedIn", true);
                    Preferences.Set("UserEmail", email);
                    Preferences.Set("UserPassword", password);
                    // (optional) You can store more user data if needed
                }
                else
                {
                    // Make sure to clear if unchecked
                    Preferences.Remove("IsSignedIn");
                    Preferences.Remove("UserEmail");
                    Preferences.Remove("UserPassword");
                }

                await DisplayAlert("Welcome", $"Hello, {userData.fname}!", "OK");

                Application.Current.MainPage = new AppShell();
            }
            else
            {
                await DisplayAlert("Login Failed", result.message, "OK");
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");
        }
    }

    // Sign Up button click handler
    private void SignUp_Clicked(object sender, EventArgs e)
    {
        Navigation.PushModalAsync(new SignUp());
    }
}
