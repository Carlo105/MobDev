using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace MauiProject_Candela;

public partial class EditCompletedTask : ContentPage
{
    private readonly Completed.ToDoItemViewModel _task;

    public EditCompletedTask(Completed.ToDoItemViewModel task)
    {
        InitializeComponent();
        _task = task;

        // Pre-fill fields
        TaskNameEntry.Text = _task.TaskName;
        DescriptionEntry.Text = _task.Description;
    }

    private async void SaveTask(object sender, EventArgs e)
    {
        var updatedData = new
        {
            item_name = TaskNameEntry.Text,
            item_description = DescriptionEntry.Text,
            item_id = _task.ItemId
        };

        var json = JsonConvert.SerializeObject(updatedData);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        try
        {
            var response = await new HttpClient().PutAsync("https://todo-list.dcism.org/editItem_action.php", content);
            var body = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode && body.Contains("\"status\":200"))
            {
                await DisplayAlert("Success", "Task updated.", "OK");

                // Update the local object
                _task.TaskName = updatedData.item_name;
                _task.Description = updatedData.item_description;

                await Navigation.PopAsync();
            }
            else
            {
                await DisplayAlert("Error", "Failed to update task.", "OK");
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", ex.Message, "OK");
        }
    }
}