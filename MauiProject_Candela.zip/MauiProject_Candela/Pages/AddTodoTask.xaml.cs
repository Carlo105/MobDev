using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;

namespace MauiProject_Candela;

public partial class AddTodoTask : ContentPage
{
    public string TaskName { get; set; }

    private readonly int userId; // We'll need to pass this in

    public AddTodoTask(int userId)
    {
        InitializeComponent();
        this.userId = userId;
        BindingContext = this;
    }

    private async void SaveTask(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(TaskName))
        {
            await DisplayAlert("Validation Error", "Please enter a task name.", "OK");
            return;
        }

        var newTask = new
        {
            item_name = TaskName,
            item_description = "Task added via app", // You can expand later
            user_id = userId,
            status = "active"
        };

        var json = JsonConvert.SerializeObject(newTask);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        try
        {
            var client = new HttpClient();
            var url = "https://todo-list.dcism.org/addItem_action.php"; // Your API
            var response = await client.PostAsync(url, content);

            if (response.IsSuccessStatusCode)
            {
                await DisplayAlert("Success", "Task added successfully!", "OK");
                await Navigation.PopModalAsync();
            }
            else
            {
                await DisplayAlert("Error", "Failed to add task.", "OK");
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", $"Something went wrong: {ex.Message}", "OK");
        }
    }
}