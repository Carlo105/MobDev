using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiProject_Candela;

public partial class Pages2 : ContentPage
{
    public Pages2()
    {
        InitializeComponent();
    }
    private void Button_Clicked(object sender, System.EventArgs e)
    {
        Navigation.PushAsync(new Pages3());
    }

}