﻿namespace MauiProject_Candela;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
    }
    
}