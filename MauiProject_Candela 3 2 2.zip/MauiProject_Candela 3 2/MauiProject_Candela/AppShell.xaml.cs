﻿using MauiProject_Candela;

namespace MauiProject_Candela;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
        Routing.RegisterRoute(nameof(ToDo), typeof(ToDo));
        Routing.RegisterRoute(nameof(Completed), typeof(Completed));
        Routing.RegisterRoute(nameof(Profile), typeof(Profile));
    }
    
}