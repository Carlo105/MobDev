using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiProject_Candela;

public partial class EditTask : ContentPage
{
    public EditTask()
    {
        InitializeComponent();
    }
}