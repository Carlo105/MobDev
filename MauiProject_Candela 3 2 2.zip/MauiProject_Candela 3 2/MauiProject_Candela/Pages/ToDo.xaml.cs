using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Microsoft.Maui.Controls;

namespace MauiProject_Candela;

public partial class ToDo : ContentPage
{
    public ObservableCollection<ToDoItem> ToDoItems { get; set; }
    public ToDo()
    {
        InitializeComponent();
        ToDoItems = new ObservableCollection<ToDoItem>
        {
            new ToDoItem("Take out Trash"),
            new ToDoItem("Buy Groceries"),
            new ToDoItem("Walk the Dog")
        };
        
        BindingContext = TaskManager.Instance;
    }
    private void TaskAdd(object sender, EventArgs e)
    {
        Navigation.PushAsync(new AddTodoTask());
    }
}

public class ToDoItem
{
    private string TaskName { get; set; }
    public ICommand DeleteCommand { get; }
    public ICommand CompleteCommand { get; }

    public ToDoItem(string taskName)
    {
        TaskName = taskName;
        DeleteCommand = new Command(DeleteTask);
        CompleteCommand = new Command(CompleteTask);
    }
    
    public string DisplayTaskName => TaskName;

    private void DeleteTask()
    {
        TaskManager.Instance.ToDoItems.Remove(this);
    }

    private void CompleteTask()
    {
        TaskManager.Instance.MarkAsCompleted(this);
    }
}