using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiProject_Candela;

public partial class Dashboard : ContentPage
{
    public Dashboard()
    {
        InitializeComponent();
    }
}