using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiProject_Candela;

public partial class AddTodoTask : ContentPage
{
    private ToDoItem _task;
    
    public AddTodoTask(ToDoItem task)
    {
        InitializeComponent();
        _task = task;
        BindingContext = _task; 
    }

    private void SaveTask(object sender, EventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(_task.TaskName))
        {
            if (!TaskManager.Instance.ToDoItems.Contains(_task))
            {
                var newTask = new ToDoItem(_task.TaskName);
                TaskManager.Instance.ToDoItems.Add(_task);
            }
            Navigation.PopAsync();
        }
        else
        { 
            DisplayAlert("Error", "Task name cannot be empty.", "OK");
        }
    }
}