using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Microsoft.Maui.Controls;
using System.ComponentModel;
using System.Windows.Input;

namespace MauiProject_Candela;

public partial class ToDo : ContentPage
{
    public ObservableCollection<ToDoItem> ToDoItems { get; set; }
    public ToDo()
    {
        InitializeComponent();
        BindingContext = TaskManager.Instance;
    }
    private void TaskAdd(object sender, EventArgs e)
    {
        var newTask = new ToDoItem(""); 
        Navigation.PushAsync(new AddTodoTask(newTask)); 
    }

    private void ToEdit(object sender, ItemTappedEventArgs e)
    {
        if (e.Item is ToDoItem selectedItem)
        {
            Navigation.PushAsync(new EditTask(selectedItem));
        }
        ((ListView)sender).SelectedItem = null;
    }
}

public class ToDoItem:INotifyPropertyChanged
{
    public event PropertyChangedEventHandler PropertyChanged;

    private string taskName;
    public string TaskName
    {
        get => taskName;
        set
        {
            if (taskName != value)
            {
                taskName = value;
                OnPropertyChanged(nameof(TaskName));
                OnPropertyChanged(nameof(DisplayTaskName)); // Ensure UI updates
            }
        }
    }
    public ICommand DeleteCommand { get; }
    public ICommand CompleteCommand { get; }

    public ToDoItem(string taskName)
    {
        TaskName = taskName;
        DeleteCommand = new Command(DeleteTask);
        CompleteCommand = new Command(CompleteTask);
    }
    
    public string DisplayTaskName => TaskName;

    private void DeleteTask()
    {
        if (TaskManager.Instance.ToDoItems.Contains(this))
        {
            TaskManager.Instance.ToDoItems.Remove(this);
        }
    }

    private void CompleteTask()
    {
        TaskManager.Instance.MarkAsCompleted(this);
    }
    
    private void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}