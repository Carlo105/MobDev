using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiProject_Candela;

public partial class EditTask : ContentPage
{
    private ToDoItem itemTask;

    public EditTask(ToDoItem task)
    {
        InitializeComponent();
        itemTask = task;
        BindingContext = itemTask;
    }
    private void SaveTask(object sender, EventArgs e)
    {
        Navigation.PopAsync(); 
    }
}