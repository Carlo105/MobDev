using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiProject_Candela;

public partial class SignIn : ContentPage
{
    public SignIn()
    {
        InitializeComponent();
    }
    private void SignIn_Clicked(object sender, System.EventArgs e)
    {
        Application.Current.MainPage = new AppShell();
    }
    private void SignUp_Clicked(object sender, System.EventArgs e)
    {
        Navigation.PushAsync(new SignUp());
    }
}