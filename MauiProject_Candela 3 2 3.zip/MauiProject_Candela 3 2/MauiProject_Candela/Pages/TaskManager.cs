using System.Collections.ObjectModel;

namespace MauiProject_Candela;

public class TaskManager
{
    private static TaskManager instance;
    public static TaskManager Instance => instance ??= new TaskManager();  // ✅ Ensure it's only created once

    public ObservableCollection<ToDoItem> ToDoItems { get; } = new ObservableCollection<ToDoItem>
    {
        new ToDoItem("Take out Trash"),
        new ToDoItem("Buy Groceries"),
        new ToDoItem("Walk the Dog")
    };

    public ObservableCollection<ToDoItem> CompletedItems { get; } = new ObservableCollection<ToDoItem>();

    public void MarkAsCompleted(ToDoItem item)
    {
        if (ToDoItems.Contains(item))
        {
            ToDoItems.Remove(item);
            CompletedItems.Add(new ToDoItem(item.TaskName));
        }
    }
}