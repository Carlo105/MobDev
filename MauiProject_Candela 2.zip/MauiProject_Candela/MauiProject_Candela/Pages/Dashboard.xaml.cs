using System;
using Microsoft.Maui.Controls;

namespace MauiProject_Candela
{
    public partial class Dashboard : ContentPage
    {
        private string _currentInput = "";
        private double _firstNumber;
        private string _operation;

        public Dashboard()
        {
            InitializeComponent();
        }

        private void OnButtonClicked(object sender, EventArgs e)
        {
            var button = sender as Button;
            if (button != null)
            {
                string buttonText = button.Text;
                if (buttonText == "C")
                {
                    Clear();
                }
                else if (buttonText == "=")
                {
                    Calculate();
                }
                else if (buttonText == "+" || buttonText == "-" || buttonText == "*" || buttonText == "/")
                {
                    // If a number is currently entered, save the first number and the operation
                    if (double.TryParse(_currentInput, out double number))
                    {
                        _firstNumber = number;
                        _operation = buttonText;
                        _currentInput = ""; // Reset current input for the next number
                        ResultEntry.Text = _currentInput; // Clear the screen for the next input
                    }
                }
                else if (buttonText == "DEL")
                {
                    // Delete the last character from the current input
                    if (_currentInput.Length > 0)
                    {
                        _currentInput = _currentInput.Substring(0, _currentInput.Length - 1);
                        ResultEntry.Text = _currentInput;
                    }
                }
                else
                {
                    // Append the button's text to the current input string
                    _currentInput += buttonText;
                    ResultEntry.Text = _currentInput;
                }
            }
        }

        private void Calculate()
        {
            if (double.TryParse(_currentInput, out double secondNumber))
            {
                switch (_operation)
                {
                    case "+":
                        ResultEntry.Text = (_firstNumber + secondNumber).ToString();
                        break;
                    case "-":
                        ResultEntry.Text = (_firstNumber - secondNumber).ToString();
                        break;
                    case "*":
                        ResultEntry.Text = (_firstNumber * secondNumber).ToString();
                        break;
                    case "/":
                        if (secondNumber != 0)
                        {
                            ResultEntry.Text = (_firstNumber / secondNumber).ToString();
                        }
                        else
                        {
                            ResultEntry.Text = "Error";
                        }

                        break;
                    default:
                        ResultEntry.Text = "Error";
                        break;
                }
            }

            _currentInput = ResultEntry.Text;
        }

        private void Clear()
        {
            _currentInput = "";
            _firstNumber = 0;
            _operation = null;
            ResultEntry.Text = "";
        }

        private void Back_Clicked(object sender, System.EventArgs e)
        {
            Navigation.PopModalAsync();
        }
    }
}
