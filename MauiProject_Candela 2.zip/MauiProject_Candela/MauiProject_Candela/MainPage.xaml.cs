﻿using MauiProject_Candela;

namespace MauiProject_Candela;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }
}