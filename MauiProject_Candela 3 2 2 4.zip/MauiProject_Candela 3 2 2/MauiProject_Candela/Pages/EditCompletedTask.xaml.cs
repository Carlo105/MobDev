using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;


namespace MauiProject_Candela;

public partial class EditCompletedTask : ContentPage
{
    private Completed.ToDoItemViewModel _task;

    public EditCompletedTask(Completed.ToDoItemViewModel task)
    {
        InitializeComponent();
        _task = task;

        // Bind the data to UI elements (example below, adjust as needed)
        TaskNameEntry.Text = _task.TaskName;
        DescriptionEntry.Text = _task.Description;
    }

    private async void SaveButton_Clicked(object sender, EventArgs e)
    {
        // Example of how to update fields and make API call, if desired
        _task.TaskName = TaskNameEntry.Text;
        _task.Description = DescriptionEntry.Text;

        // Call an update API here if you have one
        await DisplayAlert("Updated", "Task was updated locally.", "OK");

        await Navigation.PopAsync(); // Go back to the previous page
    }
}