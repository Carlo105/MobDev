using System;
using System.Collections.ObjectModel;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Microsoft.Maui.Controls;
using System.Windows.Input;

namespace MauiProject_Candela
{
    public partial class Completed : ContentPage
    {
        private readonly HttpClient _httpClient = new HttpClient();
        public ObservableCollection<ToDoItemViewModel> CompletedItems { get; set; } = new ObservableCollection<ToDoItemViewModel>();

        public Completed()
        {
            InitializeComponent();
            BindingContext = this;
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await LoadCompletedTasks();
        }

        private async Task LoadCompletedTasks()
        {
            try
            {
                var userId = Preferences.Get("UserId", 0);
                if (userId == 0)
                {
                    await DisplayAlert("Error", "No user logged in.", "OK");
                    return;
                }

                string url = $"https://todo-list.dcism.org/getItems_action.php?status=inactive&user_id={userId}";
                var response = await _httpClient.GetStringAsync(url);
                var apiResponse = JsonConvert.DeserializeObject<GetItemsResponse>(response);

                if (apiResponse.status == 200)
                {
                    CompletedItems.Clear();
                    foreach (var item in apiResponse.data.Values)
                    {
                        CompletedItems.Add(new ToDoItemViewModel
                        {
                            TaskName = item.item_name,
                            Description = item.item_description,
                            Status = item.status,
                            ItemId = item.item_id,
                            CompleteCommand = new Command(() => ReactivateTask(item.item_id)),
                            DeleteCommand = new Command(() => DeleteTask(item.item_id))
                        });
                    }
                }
                else
                {
                    await DisplayAlert("Error", "Failed to load completed tasks.", "OK");
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async Task ReactivateTask(int itemId)
        {
            try
            {
                var task = CompletedItems.FirstOrDefault(t => t.ItemId == itemId);
                if (task == null)
                {
                    await DisplayAlert("Error", "Task not found.", "OK");
                    return;
                }

                var updateUrl = "https://todo-list.dcism.org/statusItem_action.php";
                var updateData = new
                {
                    status = "active",
                    item_id = itemId
                };

                var jsonContent = JsonConvert.SerializeObject(updateData);
                var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.PutAsync(updateUrl, content);
                var responseString = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode && responseString.StartsWith("{"))
                {
                    var result = JsonConvert.DeserializeObject<UpdateTaskResponse>(responseString);
                    if (result.status == 200)
                    {
                        CompletedItems.Remove(task);
                        await DisplayAlert("Reactivated", "Task moved back to To Do list.", "OK");
                    }
                    else
                    {
                        await DisplayAlert("Error", "Failed to reactivate task.", "OK");
                    }
                }
                else
                {
                    await DisplayAlert("Error", $"Unexpected response: {responseString}", "OK");
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");
            }
        }
        private async void OnSelectionChanged(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem is ToDoItemViewModel selectedItem)
            {
                ((ListView)sender).SelectedItem = null;
                await Navigation.PushAsync(new EditCompletedTask(selectedItem));
                
                if (sender is ListView listView)
                {
                    listView.SelectedItem = null;
                }
            }
        }
        private async Task DeleteTask(int itemId)
        {
            try
            {
                var deleteUrl = $"https://todo-list.dcism.org/deleteItem_action.php?item_id={itemId}";
                var response = await _httpClient.DeleteAsync(deleteUrl);
                var responseString = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode && responseString.StartsWith("{"))
                {
                    var result = JsonConvert.DeserializeObject<UpdateTaskResponse>(responseString);
                    if (result.status == 200)
                    {
                        var task = CompletedItems.FirstOrDefault(t => t.ItemId == itemId);
                        if (task != null)
                        {
                            CompletedItems.Remove(task);
                        }

                        await DisplayAlert("Deleted", "Task was successfully deleted.", "OK");
                    }
                    else
                    {
                        await DisplayAlert("Error", "Failed to delete task.", "OK");
                    }
                }
                else
                {
                    await DisplayAlert("Error", $"Unexpected response: {responseString}", "OK");
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");
            }
        }

        public class GetItemsResponse
        {
            public int status { get; set; }
            public Dictionary<string, AuthService.TaskData> data { get; set; }
            public string count { get; set; }
        }

        public class ToDoItemViewModel
        {
            public string TaskName { get; set; }
            public int ItemId { get; set; }
            public string Status { get; set; }
            public string Description { get; set; }
            public ICommand CompleteCommand { get; set; }
            public ICommand DeleteCommand { get; set; }
        }

        public class UpdateTaskResponse
        {
            public int status { get; set; }
            public string message { get; set; }
        }
    }
}
