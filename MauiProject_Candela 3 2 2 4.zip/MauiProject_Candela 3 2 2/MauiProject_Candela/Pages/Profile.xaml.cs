using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiProject_Candela;

public partial class Profile : ContentPage
{
    public Profile()
    {
        InitializeComponent();
    }

    private async void LogOut(object sender, EventArgs e)
    {
        Application.Current.MainPage = new NavigationPage(new SignIn());
    }
    
}