using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace MauiProject_Candela;

public partial class EditTask : ContentPage
{
    private ToDo.ToDoItemViewModel _task;

    public EditTask(ToDo.ToDoItemViewModel task)
    {
        InitializeComponent();
        _task = task;

        // Pre-fill the fields with the task data
        TaskNameEntry.Text = task.TaskName;
        DescriptionEditor.Text = task.Description;
    }
    private void SaveTask(object sender, EventArgs e)
    {
        Navigation.PopAsync(); 
    }
}