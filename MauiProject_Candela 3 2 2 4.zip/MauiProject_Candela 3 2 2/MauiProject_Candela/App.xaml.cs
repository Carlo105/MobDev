﻿using Android.Preferences;

namespace MauiProject_Candela;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        Window window = new Window(new NavigationPage(new SignIn()));
        
        if (Preferences.Default.Get("IsSignedIn", false) && Preferences.Default.ContainsKey("UserEmail"))
        {
            window = new Window(new NavigationPage(new AppShell()));
        }

        return window;
    }
}