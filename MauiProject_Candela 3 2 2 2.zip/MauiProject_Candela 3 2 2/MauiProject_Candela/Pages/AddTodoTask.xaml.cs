using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiProject_Candela;

public partial class AddTodoTask : ContentPage
{
    private ToDoItem _task;
    
    public AddTodoTask()
    {
        InitializeComponent();
        _task = new ToDoItem(""); // ✅ This will ensure commands are initialized
        BindingContext = _task;
    }



    private async void SaveTask(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(_task.TaskName))
        {
            await DisplayAlert("Error", "Task name cannot be empty.", "OK");
            return;
        }
        var newTask = _task;

        if (!TaskManager.Instance.ToDoItems.Any(t => t.TaskName == newTask.TaskName))
        {
            TaskManager.Instance.ToDoItems.Add(newTask);
        }

        await Navigation.PopAsync();
    }




}