using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiProject_Candela;

public partial class EditCompletedTask : ContentPage
{
    private ToDoItem itemTask;

    public EditCompletedTask(ToDoItem task)
    {
        InitializeComponent();
        itemTask = task;
        BindingContext = itemTask;
    }
    private void SaveTask(object sender, EventArgs e)
    {
        Navigation.PopAsync(); 
    }
}