using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace MauiProject_Candela;

public partial class SignIn : ContentPage
{
    public SignIn()
    {
        InitializeComponent();
    }
    private async void SignIn_Clicked(object sender, EventArgs e)
    {
        // Get the email and password from the input fields
        var email = EmailEntry.Text; // Assuming you have an EmailEntry field in XAML
        var password = PasswordEntry.Text; // Assuming you have a PasswordEntry field in XAML

        // Validate input fields
        if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
        {
            await DisplayAlert("Error", "Please enter both email and password.", "OK");
            return;
        }

        // Prepare the request URL with email and password as query parameters
        var signInUrl = $"https://todo-list.dcism.org/signin_action.php?email={Uri.EscapeDataString(email)}&password={Uri.EscapeDataString(password)}";

        try
        {
            // Make the GET request to the API
            var httpClient = new HttpClient();
            var response = await httpClient.GetStringAsync(signInUrl);

            // Deserialize the response
            var result = JsonConvert.DeserializeObject<AuthService.SignInResponse>(response);

            // Check if login was successful
            if (result.status == 200)
            {
                var userData = result.data;

                // Show a welcome message
                await DisplayAlert("Welcome", $"Hello, {userData.fname}!", "OK");

                // Navigate to the main page (e.g., AppShell)
                Application.Current.MainPage = new AppShell();
            }
            else
            {
                // Handle login failure
                await DisplayAlert("Login Failed", result.message, "OK");
            }
        }
        catch (Exception ex)
        {
            // Handle any errors during the API call
            await DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");
        }
    }

    // Sign Up button click handler
    private void SignUp_Clicked(object sender, EventArgs e)
    {
        Navigation.PushModalAsync(new SignUp());
    }
}
