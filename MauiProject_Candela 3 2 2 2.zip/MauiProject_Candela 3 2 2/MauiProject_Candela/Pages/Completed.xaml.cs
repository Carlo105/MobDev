using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiProject_Candela;

public partial class Completed : ContentPage
{
    public Completed()
    {
        InitializeComponent();
        BindingContext = TaskManager.Instance;
    }
    

    private void EditCompleted(object sender, ItemTappedEventArgs e)
    {
        if (e.Item is ToDoItem selectedItem)
        {
            Navigation.PushAsync(new EditCompletedTask(selectedItem));
        }
        ((ListView)sender).SelectedItem = null;
    }
}