using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Microsoft.Maui.Controls;
using System.ComponentModel;
using System.Windows.Input;

namespace MauiProject_Candela;

public partial class ToDo : ContentPage
{
    
}
