using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace MauiProject_Candela
{
    public class AuthService
    {
        private readonly HttpClient _client;
        private const string BaseUrl = "https://todo-list.dcism.org";

        public AuthService()
        {
            _client = new HttpClient();
        }

        public static async Task<SignUpResponse> SignUp(SignUpRequest request)
        {
            var url = "https://todo-list.dcism.org/signup_action.php";

            var jsonData = JsonConvert.SerializeObject(request);
            var byteArray = Encoding.UTF8.GetBytes(jsonData);

            var webRequest = (System.Net.HttpWebRequest)WebRequest.Create(url);
            webRequest.Method = "POST";
            webRequest.ContentType = "application/json";
            webRequest.ContentLength = byteArray.Length;

            using (var stream = await webRequest.GetRequestStreamAsync())
            {
                await stream.WriteAsync(byteArray, 0, byteArray.Length);
            }

            using (var response = (HttpWebResponse)await webRequest.GetResponseAsync())
            {
                using (var reader = new StreamReader(response.GetResponseStream()))
                {
                    var resultJson = await reader.ReadToEndAsync();
                    return JsonConvert.DeserializeObject<SignUpResponse>(resultJson);
                }
            }
        }

        // 🔓 Sign In
        public async Task<(bool IsSuccess, string Message, UserData Data)> SignInAsync(string email, string password)
        {
            var signInUrl = $"{BaseUrl}/signin_action.php?email={Uri.EscapeDataString(email)}&password={Uri.EscapeDataString(password)}";

            try
            {
                var response = await _client.GetAsync(signInUrl);
                var resultString = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<SignInResponse>(resultString);

                return (result.status == 200, result.message, result.data);
            }
            catch (Exception ex)
            {
                return (false, $"Error: {ex.Message}", null);
            }
        }

        // Response classes
        private class ApiResponse
        {
            public int status { get; set; }
            public string message { get; set; }
        }

        public class SignInResponse
        {
            public int status { get; set; }
            public string message { get; set; }
            public UserData data { get; set; }
        }
        
        public class SignUpRequest
        {
            public string first_name { get; set; }
            public string last_name { get; set; }
            public string email { get; set; }
            public string password { get; set; }
            public string confirm_password { get; set; }
        }

        public class SignUpResponse
        {
            public int status { get; set; }
            public string message { get; set; }
        }

        public class UserData
        {
            public int id { get; set; }
            public string fname { get; set; }
            public string lname { get; set; }
            public string email { get; set; }
            public string timemodified { get; set; }
        }

    }
}
