using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace MauiProject_Candela;

public partial class SignUp : ContentPage
{
    public SignUp()
    {
        InitializeComponent();
    }
    private async void SignUp_Clicked(object sender, EventArgs e)
    {
        var request = new AuthService.SignUpRequest()
        {
            first_name = FirstNameEntry.Text,
            last_name = LastNameEntry.Text,
            email = EmailEntry.Text,
            password = PasswordEntry.Text,
            confirm_password = ConfirmPasswordEntry.Text
        };

        if (string.IsNullOrWhiteSpace(request.email) ||
            string.IsNullOrWhiteSpace(request.password) ||
            request.password != request.confirm_password)
        {
            await DisplayAlert("Error", "Please fill all fields correctly.", "OK");
            return;
        }

        try
        {
            var result = await AuthService.SignUp(request);

            if (result.status == 200)
            {
                await DisplayAlert("Success", result.message, "OK");
                await Navigation.PopModalAsync(); // Back to Sign In
            }
            else
            {
                await DisplayAlert("Error", result.message, "OK");
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Network Error", ex.Message, "OK");
        }
    }


    private void Back_Clicked(object sender, System.EventArgs e)
    {
        Navigation.PopModalAsync();
    }
}