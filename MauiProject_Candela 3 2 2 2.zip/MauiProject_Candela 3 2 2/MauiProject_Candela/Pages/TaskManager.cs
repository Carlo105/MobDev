using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;

namespace MauiProject_Candela;

public class TaskManager : INotifyPropertyChanged
{
    private static TaskManager _instance;
    public static TaskManager Instance => _instance ??= new TaskManager();

    private ObservableCollection<ToDoItem> _toDoItems;
    private ObservableCollection<ToDoItem> _completedItems;

    public event PropertyChangedEventHandler PropertyChanged;

    public ObservableCollection<ToDoItem> ToDoItems
    {
        get => _toDoItems;
        private set
        {
            _toDoItems = value;
            OnPropertyChanged(nameof(ToDoItems));
        }
    }

    public ObservableCollection<ToDoItem> CompletedItems
    {
        get => _completedItems;
        private set
        {
            _completedItems = value;
            OnPropertyChanged(nameof(CompletedItems));
        }
    }

    private TaskManager()
    {
        _toDoItems = new ObservableCollection<ToDoItem>
        {
            new ToDoItem("Take out Trash"),
            new ToDoItem("Buy Groceries"),
            new ToDoItem("Walk the Dog")
        };

        _completedItems = new ObservableCollection<ToDoItem>();
    }

    // ✅ Add a Task
    public void AddTask(string taskName)
    {
        if (!string.IsNullOrWhiteSpace(taskName))
        {
            MainThread.BeginInvokeOnMainThread(() =>
            {
                var newTask = new ToDoItem(taskName);
                _toDoItems.Add(newTask);
                OnPropertyChanged(nameof(ToDoItems));
            });
        }
    }

    // ✅ Edit a Task
    public void EditTask(ToDoItem task, string newTaskName)
    {
        if (task != null && !string.IsNullOrWhiteSpace(newTaskName))
        {
            MainThread.BeginInvokeOnMainThread(() =>
            {
                task.TaskName = newTaskName;
                OnPropertyChanged(nameof(ToDoItems));
            });
        }
    }

    // ✅ Mark Task as Completed
    public void MarkAsCompleted(ToDoItem task)
    {
        if (task == null) return;

        MainThread.BeginInvokeOnMainThread(() =>
        {
            if (_toDoItems.Contains(task))
            {
                _toDoItems.Remove(task);
                _completedItems.Add(new ToDoItem(task.TaskName));
                OnPropertyChanged(nameof(ToDoItems));
                OnPropertyChanged(nameof(CompletedItems));
            }
        });
    }

    // ✅ Remove Task
    public void RemoveTask(ToDoItem task)
    {
        if (task == null) return;

        MainThread.BeginInvokeOnMainThread(() =>
        {
            if (_toDoItems.Contains(task))
            {
                _toDoItems.Remove(task);
                task.RefreshTracking();
                OnPropertyChanged(nameof(ToDoItems));
            }
            else if (_completedItems.Contains(task))
            {
                _completedItems.Remove(task);
                task.RefreshTracking();
                OnPropertyChanged(nameof(CompletedItems));
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("⚠️ Task not found in either list.");
            }
        });
    }

    // 🔥 Notify UI of Changes
    private void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}

// ========================== ToDoItem Class ==========================

public class ToDoItem : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler PropertyChanged;

    private string _taskName;
    public string TaskName
    {
        get => _taskName;
        set
        {
            if (_taskName != value)
            {
                _taskName = value;
                OnPropertyChanged(nameof(TaskName));
            }
        }
    }

    public ICommand DeleteCommand { get; }
    public ICommand CompleteCommand { get; }

    public ToDoItem(string taskName)
    {
        TaskName = taskName;
        DeleteCommand = new Command(() => TaskManager.Instance.RemoveTask(this));
        CompleteCommand = new Command(() => TaskManager.Instance.MarkAsCompleted(this));
    }
        public bool IsTracked
        {
            get => TaskManager.Instance.ToDoItems.Contains(this);
        }

        // Call this when you want to refresh it:
        public void RefreshTracking()
        {
            OnPropertyChanged(nameof(IsTracked));
        }

        // ... existing OnPropertyChanged method ...

    private void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
