using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Microsoft.Maui.Controls;
using System.Text;
using System.Windows.Input;

namespace MauiProject_Candela
{
    public partial class ToDo : ContentPage
    {
        private readonly HttpClient _httpClient = new HttpClient();
        public ObservableCollection<ToDoItemViewModel> ToDoItems { get; set; } = new ObservableCollection<ToDoItemViewModel>();

        public ToDo()
        {
            InitializeComponent();
            BindingContext = this;
            LoadTasks("active"); // Load active tasks by default
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            // Ensure that we have the userId from Preferences when the page appears
            var userId = Preferences.Get("UserId", 0);
            if (userId != 0)
            {
                LoadTasks("active"); // or load "inactive" tasks if required
            }
            else
            {
                // Handle the case when the user is not logged in
                DisplayAlert("Error", "No user logged in.", "OK");
            }
        }

        private async Task LoadTasks(string status)
        {
            try
            {
                var userId = Preferences.Get("UserId", 0);
                if (userId == 0)
                {
                    await DisplayAlert("Error", "No user logged in.", "OK");
                    return;
                }

                string url = $"https://todo-list.dcism.org/getItems_action.php?status={status}&user_id={userId}";
                var response = await _httpClient.GetStringAsync(url);

                var apiResponse = JsonConvert.DeserializeObject<GetItemsResponse>(response);

                if (apiResponse.status == 200)
                {
                    ToDoItems.Clear(); // Clear old items

                    foreach (var item in apiResponse.data.Values)
                    {
                        ToDoItems.Add(new ToDoItemViewModel
                        {
                            ItemId = item.item_id,  // Ensure to map the ItemId
                            TaskName = item.item_name,
                            Description = item.item_description,
                            Status = item.status,  // Use the status from the API
                            DeleteCommand = new Command( () => DeleteTask(item.item_id)),
                            CompleteCommand = new Command(() =>  CompleteTask(item.item_id))
                        });
                    }
                }
                else
                {
                    await DisplayAlert("Error", "Failed to load tasks.", "OK");
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }


        private async Task DeleteTask(int itemId)
        {
            // ❗TODO: Implement API delete call
            await DisplayAlert("Delete", $"Delete task with ID: {itemId}", "OK");
        }
        private async Task CompleteTask(int itemId)
        {
            try
            {
                var task = ToDoItems.FirstOrDefault(t => t.ItemId == itemId);
                if (task == null)
                {
                    await DisplayAlert("Error", "Task not found.", "OK");
                    return;
                }
                var updateUrl = "https://todo-list.dcism.org/statusItem_action.php";
                var updateData = new
                {
                    status = "inactive",  
                    item_id = itemId
                };

                var jsonContent = JsonConvert.SerializeObject(updateData);
                var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.PutAsync(updateUrl, content);
                var responseString = await response.Content.ReadAsStringAsync();

                Console.WriteLine("Raw Response: " + responseString);

                if (response.IsSuccessStatusCode && !string.IsNullOrWhiteSpace(responseString) && responseString.StartsWith("{"))
                {
                    var result = JsonConvert.DeserializeObject<UpdateTaskResponse>(responseString);

                    if (result.status == 200)
                    {
                        // Mark the task as inactive
                        task.Status = "inactive";

                        // Optionally, remove it from the list
                        ToDoItems.Remove(task);

                        await DisplayAlert("Success", "Task marked as complete.", "OK");
                    }
                    else
                    {
                        await DisplayAlert("Error", "Failed to update task.", "OK");
                    }
                }
                else
                {
                    await DisplayAlert("Error", $"Unexpected response: {responseString}", "OK");
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");
            }
        }
        
        // Response classes
        public class GetItemsResponse
        {
            public int status { get; set; }
            public Dictionary<string, AuthService.TaskData> data { get; set; }
            public string count { get; set; }
        }

        public class ToDoItemViewModel
        {
            public string TaskName { get; set; }
            public int ItemId { get; set; }
            public string Status {get; set; }
            public string Description { get; set; }
            public bool IsTracked { get; set; }

            public ICommand DeleteCommand { get; set; }
            public ICommand CompleteCommand { get; set; }
        }
        
        public class UpdateTaskResponse
        {
            public int status { get; set; }
            public string message { get; set; }
        }
        private async void AddButtonPressed(object sender, EventArgs e)
        {
            var userId = Preferences.Get("UserId", 0);
            if (userId != 0)
            {
                await Navigation.PushModalAsync(new AddTodoTask(userId));
            }
            else
            {
                await DisplayAlert("Error", "You must be signed in to add a task.", "OK");
            }
        }
    }
}
