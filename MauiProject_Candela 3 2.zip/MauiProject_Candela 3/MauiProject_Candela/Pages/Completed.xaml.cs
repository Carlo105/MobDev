using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiProject_Candela;

public partial class Completed : ContentPage
{
    public Completed()
    {
        InitializeComponent();
    }

    private void EditCompleted(object sender, EventArgs e)
    {
        Navigation.PushAsync(new EditCompletedTask());
    }
}