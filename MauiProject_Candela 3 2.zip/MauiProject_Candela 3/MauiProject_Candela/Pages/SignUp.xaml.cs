using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiProject_Candela;

public partial class SignUp : ContentPage
{
    public SignUp()
    {
        InitializeComponent();
    }
    private void SignUp_Clicked(object sender, System.EventArgs e)
    {
        Navigation.PushModalAsync(new SignIn());
    }

    private void Back_Clicked(object sender, System.EventArgs e)
    {
        Navigation.PopModalAsync();
    }
}