using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiProject_Candela;

public partial class ToDo : ContentPage
{
    public ToDo()
    {
        InitializeComponent();
    }

    private void TaskAdd(object sender, EventArgs e)
    {
        Navigation.PushAsync(new AddTodoTask());
    }
}